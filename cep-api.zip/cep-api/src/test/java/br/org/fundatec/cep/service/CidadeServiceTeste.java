package br.org.fundatec.cep.service;

import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.CidadeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class CidadeServiceTeste {

    @Mock
    private CidadeRepository cidadeRepository;

    @InjectMocks
    private CidadeService cidadeService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSalvarCidade() {
        // Mockando o retorno do repository
        Cidade cidadeMock = new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS"));
        when(cidadeRepository.save(any(Cidade.class))).thenReturn(cidadeMock);

        // Chamando o método do serviço
        Cidade cidadeSalva = cidadeService.salvar(new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS")));

        // Confere se foi chamado e se o resultado é o certo
        verify(cidadeRepository, times(1)).save(any(Cidade.class));
        assertEquals("Porto Alegre", cidadeSalva.getNome());
        assertEquals("RS", cidadeSalva.getUf());
    }

    @Test
    public void testBuscarCidadeExistente() {
        Cidade cidadeMock = new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS"));
        when(cidadeRepository.findById(1)).thenReturn(Optional.of(cidadeMock));


        Cidade cidadeEncontrada = cidadeService.busca(1);

        verify(cidadeRepository, times(1)).findById(1);
        assertEquals("Porto Alegre", cidadeEncontrada.getNome());
        assertEquals("RS", cidadeEncontrada.getUf());
    }

    @Test
    public void testBuscarCidadeNaoExistente() {
        when(cidadeRepository.findById(1)).thenReturn(Optional.empty());

        // Confere a exceção adequada
        assertThrows(RegistroNaoEcontradoException.class, () -> cidadeService.busca(1));
    }

    @Test
    public void testBuscarTodas() {
        List<Cidade> cidadesMock = Arrays.asList(new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS")));
        when(cidadeRepository.findAll()).thenReturn(cidadesMock);

        List<Cidade> cidades = cidadeService.buscaTodos();

        verify(cidadeRepository, times(1)).findAll();
        assertEquals(1, cidades.size());
        assertEquals("Porto Alegre", cidades.get(0).getNome());
        assertEquals("RS", cidades.get(0).getUf());
    }

    @Test
    public void testBuscarPorUf() {
        List<Cidade> cidadesMock = Arrays.asList(new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS")));
        when(cidadeRepository.findByUf_UfContaining("RS")).thenReturn(cidadesMock);

        List<Cidade> cidades = cidadeService.buscaPorUf("RS");

        verify(cidadeRepository, times(1)).findByUf_UfContaining("RS");
        assertEquals(1, cidades.size());
        assertEquals("Porto Alegre", cidades.get(0).getNome());
        assertEquals("RS", cidades.get(0).getUf());
    }

    @Test
    public void testRemoverCidadeExistente() {
        Cidade cidadeMock = new Cidade("Porto Alegre", new Uf("Rio Grande do Sul", "RS"));
        when(cidadeRepository.findById(1)).thenReturn(Optional.of(cidadeMock));

        cidadeService.remover(1);

        verify(cidadeRepository, times(1)).delete(cidadeMock);
    }
}


