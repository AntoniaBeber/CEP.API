package br.org.fundatec.cep.service;

import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Cep;
import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.CepRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class CepServiceTest {

    @Mock
    private CepRepository cepRepository;

    @InjectMocks
    private CepService service;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testaAdicao() {
        Cep inserir = build(99999999, "SC", "Timbo", "Rua Pomeranos");

        when(cepRepository.save(eq(inserir))).thenReturn(inserir);

        Cep retorno = service.salvar(inserir);

        verify(cepRepository, times(1)).save(eq(inserir));
        assertThat("Não retornou o CEP Correto", retorno.getCep(), equalTo(inserir.getCep()));
    }

    @Test
    void testaListagem() {
        List<Cep> listagem = new ArrayList<>();
        listagem.add(build(99999999, "SC", "Timbo", "Rua Pomeranos"));

        when(cepRepository.findAll()).thenReturn(listagem);

        List<Cep> retorno = service.buscaTodos();

        verify(cepRepository, times(1)).findAll();
        assertThat("Não retornou o CEP Correto", retorno.get(0).getCep(), equalTo(listagem.get(0).getCep()));
    }

    @Test
    void testaBuscaPorCep() {
        Optional<Cep> cep = Optional.of(build(99999999, "SC", "Timbo", "Rua Pomeranos"));

        when(cepRepository.findById(99999999)).thenReturn(cep);

        Cep retorno = service.busca(99999999);

        verify(cepRepository, times(1)).findById(99999999);
        assertThat("Não retornou o CEP Correto", retorno.getCep(), equalTo(cep.get().getCep()));
    }

    @Test
    void testaBuscaCepNaoEcontrado() {
        Optional<Cep> cep = Optional.empty();

        when(cepRepository.findById(99999999)).thenReturn(cep);

        try {
            service.busca(99999999);
            assertThat("Não falhou", false);
        } catch (RegistroNaoEcontradoException e) {
            assertThat("Não retornou o CEP Correto", e.getMessage(), equalTo("Cep: 99999999 nao encontrado"));
        }

        verify(cepRepository, times(1)).findById(99999999);
    }

    @Test
    void testaRemover() {
        Optional<Cep> cep = Optional.of(build(99999999, "SC", "Timbo", "Rua Pomeranos"));

        when(cepRepository.findById(99999999)).thenReturn(cep);
        doNothing().when(cepRepository).delete(eq(cep.get()));

        service.remover(99999999);

        verify(cepRepository, times(1)).findById(99999999);
        verify(cepRepository, times(1)).delete(eq(cep.get()));
    }

    @Test
    void testaRemoverRegistroNaoEcontrado() {
        Optional<Cep> cep = Optional.empty();

        when(cepRepository.findById(99999999)).thenReturn(cep);

        try {
            service.remover(99999999);
            assertThat("Não falhou", false);
        } catch (RegistroNaoEcontradoException e) {
            assertThat("Não retornou o CEP Correto", e.getMessage(), equalTo("Cep: 99999999 nao encontrado"));
        }

        verify(cepRepository, times(1)).findById(99999999);
    }

    private Cep build(Integer cep, String uf, String cidade, String logradouro) {
        Uf ufObj = new Uf(uf, "NomeUF");
        Cidade cidadeObj = new Cidade(cidade, ufObj);
        return new Cep(cep, cidadeObj, logradouro, 0, 1000);
    }


}
