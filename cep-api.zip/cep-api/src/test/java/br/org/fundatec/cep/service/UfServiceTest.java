package br.org.fundatec.cep.service;

import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.UfRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class UfServiceTest {

    @Mock
    private UfRepository ufRepository;

    @InjectMocks
    private UfService ufService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSalvarUf() {
        Uf ufMock = new Uf("RS", "Rio Grande do Sul");
        when(ufRepository.save(any(Uf.class))).thenReturn(ufMock);

        Uf ufSalva = ufService.salvar(new Uf("RS", "Rio Grande do Sul"));

        verify(ufRepository, times(1)).save(any(Uf.class));
        assertEquals("RS", ufSalva.getUf());
        assertEquals("Rio Grande do Sul", ufSalva.getNomeUf());
    }

    @Test
    public void testBuscarUfExistente() {
        Uf ufMock = new Uf("RS", "Rio Grande do Sul");
        when(ufRepository.findById(1L)).thenReturn(Optional.of(ufMock));

        Uf ufEncontrada = ufService.busca("RS");

        verify(ufRepository, times(1)).findById(1L);
        assertEquals("RS", ufEncontrada.getUf());
        assertEquals("Rio Grande do Sul", ufEncontrada.getNomeUf());
    }

    @Test
    public void testBuscarUfNaoExistente() {
        when(ufRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RegistroNaoEcontradoException.class, () -> ufService.busca("RS"));
    }

    @Test
    public void testBuscarTodos() {
        List<Uf> ufsMock = Arrays.asList(new Uf("RS", "Rio Grande do Sul"));
        when(ufRepository.findAll()).thenReturn(ufsMock);

        List<Uf> ufs = ufService.buscaTodos();

        verify(ufRepository, times(1)).findAll();
        assertEquals(1, ufs.size());
        assertEquals("RS", ufs.get(0).getUf());
        assertEquals("Rio Grande do Sul", ufs.get(0).getNomeUf());
    }

    @Test
    public void testRemoverUfExistente() {
        Uf ufMock = new Uf("RS", "Rio Grande do Sul");
        when(ufRepository.findById(1L)).thenReturn(Optional.of(ufMock));

        ufService.remover("RS");

        verify(ufRepository, times(1)).delete(ufMock);
    }

    @Test
    public void testRemoverUfNaoExistente() {
        when(ufRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RegistroNaoEcontradoException.class, () -> ufService.remover("RS"));
    }
}
