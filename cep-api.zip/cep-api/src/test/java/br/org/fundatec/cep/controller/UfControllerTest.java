package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.model.Uf;
import br.org.fundatec.cep.repository.UfRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UfController.class)
public class UfControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UfRepository ufRepository;

    private Uf uf;

    @BeforeEach
    public void setUp() {

    }

    @Test
    public  void Uf1() {
        Uf uf1 = new Uf("Rio Grande do Sul", "RS");
    }

    @Test
    public  void Uf2() {
        Uf uf1 = new Uf("Santa Catarina", "SC");
    }

    @Test
    public void testListUfs() throws Exception {

        Mockito.when(ufRepository.findAll()).thenReturn(Collections.singletonList(uf));

        mockMvc.perform(get("/ufs")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].uf").value("RS"))
                .andExpect(jsonPath("$[0].nomeUf").value("SC"));
    }


}
