package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.exception.ParametroInvalidoException;
import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import br.org.fundatec.cep.model.Cep;
import br.org.fundatec.cep.service.CepService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//Define o Paths
@RestController
@RequestMapping(path = "ceps")
public class CepController {

    @Autowired
    private CepService cepService;

    //Buscar CEPs
    @GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<Cep>> get() {
        return ResponseEntity.status(HttpStatus.OK).body(cepService.buscaTodos());
    }

    //Buscar CEP pelo Número
    @GetMapping(value = "{cep}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Cep> get(@PathVariable("cep") Integer numCep) {
        Cep retorno = cepService.busca(numCep);
        return ResponseEntity.status(HttpStatus.OK).body(retorno);
    }

    //Buscar CEP pela cidade
    @GetMapping(value = "consulta", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<Cep>> get(@RequestParam("cidade") String cidade) {
        return ResponseEntity.status(HttpStatus.OK).body(cepService.busca(cidade));
    }

    //Buscar CEP pela UF
    @GetMapping(value = "uf/{uf}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<Cep>> getByUf(@PathVariable("uf") String uf) {
        return ResponseEntity.status(HttpStatus.OK).body(cepService.busca(uf));
    }

    //Adiciona CEP
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Cep> adicionar(@RequestBody @Valid Cep cep) {
        return ResponseEntity.status(HttpStatus.CREATED).body(cepService.salvar(cep));
    }

    //Edita CEP
    @PutMapping(value = "{cep}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Cep> editar(@PathVariable("cep") Integer numCep, @RequestBody Cep cep) {
        return ResponseEntity.status(HttpStatus.OK).body(cepService.editar(numCep, cep));
    }

    //Deleta CEP
    @DeleteMapping(value = "{cep}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> remover(@PathVariable("cep") Integer numCep) {
        cepService.remover(numCep);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    //Parametro para definir se é invalido
    @ExceptionHandler(ParametroInvalidoException.class)
    public ResponseEntity<String> handleParametroInvalidoException(ParametroInvalidoException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

    //Parametro não Registrado
    @ExceptionHandler(RegistroNaoEcontradoException.class)
    public ResponseEntity<String> handleRegistroNaoEcontradoException(RegistroNaoEcontradoException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
}
