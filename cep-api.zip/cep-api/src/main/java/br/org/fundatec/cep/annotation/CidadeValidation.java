package br.org.fundatec.cep.annotation;

import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface CidadeValidation {

    Class<?>[] groups() default {};

    String message() default "Cidade inválida";

    Class<? extends Payload>[] payload() default {};
}
