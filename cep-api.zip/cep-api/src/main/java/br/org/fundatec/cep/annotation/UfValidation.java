package br.org.fundatec.cep.annotation;

import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface UfValidation {

    Class<?>[] groups() default {};

    String message() default "UF inválida";

    Class<? extends Payload>[] payload() default {};
}
