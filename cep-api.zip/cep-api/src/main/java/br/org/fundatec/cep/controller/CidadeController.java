package br.org.fundatec.cep.controller;

import br.org.fundatec.cep.model.Cidade;
import br.org.fundatec.cep.repository.CidadeRepository;
import br.org.fundatec.cep.exception.RegistroNaoEcontradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "cidades")
public class CidadeController {

    @Autowired
    private CidadeRepository cidadeRepository;

    //Cria a cidadde
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Cidade> createCidade(@RequestBody Cidade cidade) {
        Cidade novaCidade = cidadeRepository.save(cidade);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaCidade);
    }
    //Lista as cidade
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cidade>> listCidades() {
        List<Cidade> cidades = cidadeRepository.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(cidades);
    }
    //Lista cidades por UF
    @GetMapping(value = "/uf/{uf}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cidade>> listCidadesByUf(@PathVariable String uf) {
        List<Cidade> cidades = cidadeRepository.findByUf_UfContaining(uf);
        if (cidades.isEmpty()) {
            throw new RegistroNaoEcontradoException("Nenhuma cidade encontrada para a UF: " + uf);
        }
        return ResponseEntity.status(HttpStatus.OK).body(cidades);
    }
    //Parametro de Registro N encontrado
    @ExceptionHandler(RegistroNaoEcontradoException.class)
    public ResponseEntity<String> handleRegistroNaoEcontradoException(RegistroNaoEcontradoException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
}
