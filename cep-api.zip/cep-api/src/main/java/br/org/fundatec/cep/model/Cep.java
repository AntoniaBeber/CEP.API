package br.org.fundatec.cep.model;

import br.org.fundatec.cep.annotation.CepValidation;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Objects;

@Entity
@Table(name = "cep")
public class Cep {

    @Id
    @CepValidation(message = "Cep invalida")
    private Integer cep;

    @ManyToOne
    @JoinColumn(name = "idCidade", nullable = false)
    private Cidade cidade;

    @Column(name = "logradouro",nullable = false)
    @NotBlank(message = "Logradouro não pode ser nulo")
    private String logradouro;

    @Column(name = "numInicio",nullable = false)
    @NotNull(message = "Número de início não pode ser nulo")
    private Integer numInicio;

    @Column(name = "numFim",nullable = false)
    @NotNull(message = "Número de fim não pode ser nulo")
    private Integer numFim;

    public Cep() {
    }

    public Cep(Integer cep, Cidade cidade, String logradouro, Integer numInicio, Integer numFim) {
        this.cep = cep;
        this.cidade = cidade;
        this.logradouro = logradouro;
        this.numInicio = numInicio;
        this.numFim = numFim;
    }


    public Integer getCep() {
        return cep;
    }

    public void setCep(Integer cep) {
        this.cep = cep;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public Integer getNumInicio() {
        return numInicio;
    }

    public void setNumInicio(Integer numInicio) {
        this.numInicio = numInicio;
    }

    public Integer getNumFim() {
        return numFim;
    }

    public void setNumFim(Integer numFim) {
        this.numFim = numFim;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cep cep1 = (Cep) o;
        return Objects.equals(cep, cep1.cep);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cep);
    }
}
